package com.cogni.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cogni.entity.Department;
import com.cogni.repository.DepartmentRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DepartmentService {
	
    @Autowired
    private DepartmentRepository departmentRepository;

    public Department saveDepartment(Department department) {
        //log.info("Inside saveDepartment of service class");
        return departmentRepository.save(department);
    }
    
    public Department findByDepartmentId(long departmentId) {
        //log.info("Inside findByDepartmentId of service class");
        return departmentRepository.getById(departmentId);
        
    }

 

}
 
