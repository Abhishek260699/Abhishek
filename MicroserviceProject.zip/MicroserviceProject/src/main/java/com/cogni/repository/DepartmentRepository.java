package com.cogni.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cogni.entity.Department;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
	
	//Department getByDepartmentId(long DepartmentId);

}
