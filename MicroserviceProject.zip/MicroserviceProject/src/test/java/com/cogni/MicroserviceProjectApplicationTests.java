package com.cogni;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
