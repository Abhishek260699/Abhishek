package com.contact.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.contact.entity.Contact;

@Service
public class ContactServiceImpl implements ContactService {
	
	//Fake list of contacts
	//Long cId, String email, String contactName, Long userId
	List <Contact>list=List.of(
			new Contact(1L,"abc@cde","Abhi",11L),
			new Contact(2L,"ab65c@cde","3s5Abhi",12L),
			new Contact(3L,"ahbc@cde","Abh354i",13L));

	@Override
	public List<Contact> getContactOfUser(Long userId) {
		// TODO Auto-generated method stub
		return list.stream().filter(contact ->contact.getUserId().equals(userId)).collect(Collectors.toList());
	}

}
