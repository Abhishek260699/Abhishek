package com.user.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.user.entity.User;

@Service
public class UserServiceImpl implements UserService {

	
	//Fake list
	List<User> list=List.of(
			new User(11L,"Abhi","457147"),
			new User(12L, "Pooja","21556350"),
			new User(13L, "Sarika","42178")
			);
			
	@Override
	public User getUser(Long id) {
		// TODO Auto-generated method stub
		return list.stream().filter(user -> user.getUserId().equals(id)).findAny().orElse(null);
	}

	

}
